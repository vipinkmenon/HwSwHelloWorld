/*
 * ledControl.c
 *
 *  Created on: Feb 10, 2020
 *      Author: VIPIN
 */


//#include "xparameters.h"
#include <xil_io.h>


int main(){
	//Xil_Out8(XPAR_GPIO_0_BASEADDR,0xFF);
	xil_printf("Hello\n\r");
}


